

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useCreateProductMutation } from "../../services/productsApi";

const NewProductPage: React.FC = () => {
  const navigate = useNavigate();
  const [createProduct, { isLoading }] = useCreateProductMutation();

  const [formData, setFormData] = useState({
    name: "",
    sku: "",
    categoryId: "",
    supplierId: "",
    price: "",
    quantity: "",
    description: "",
    imageUrl: "",
    lowStockThreshold: ""
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      await createProduct({
        name: formData.name,
        sku: formData.sku || null,
        price: parseFloat(formData.price),
        quantity: parseInt(formData.quantity),
        description: formData.description || null,
        supplierId: parseInt(formData.supplierId),
        categoryId: parseInt(formData.categoryId),
        imageUrl: formData.imageUrl || null,
        lowStockThreshold: parseInt(formData.lowStockThreshold || "0"),
        isActive: true
      }).unwrap();

      navigate("/products");
    } catch (error) {
      console.error("Failed to create product:", error);
      alert("Failed to create product. Check console for details.");
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Add New Product</h1>

      <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6 space-y-4">
        <input
          type="text"
          name="name"
          placeholder="Product Name"
          value={formData.name}
          onChange={handleChange}
          required
          className="w-full border rounded p-2"
        />

        <input
          type="text"
          name="sku"
          placeholder="SKU"
          value={formData.sku}
          onChange={handleChange}
          className="w-full border rounded p-2"
        />

        <input
          type="number"
          name="price"
          placeholder="Price"
          value={formData.price}
          onChange={handleChange}
          required
          className="w-full border rounded p-2"
        />

        <input
          type="number"
          name="quantity"
          placeholder="Quantity"
          value={formData.quantity}
          onChange={handleChange}
          required
          className="w-full border rounded p-2"
        />

        <input
          type="number"
          name="categoryId"
          placeholder="Category ID"
          value={formData.categoryId}
          onChange={handleChange}
          required
          className="w-full border rounded p-2"
        />

        <input
          type="number"
          name="supplierId"
          placeholder="Supplier ID"
          value={formData.supplierId}
          onChange={handleChange}
          required
          className="w-full border rounded p-2"
        />

        <input
          type="text"
          name="imageUrl"
          placeholder="Image URL"
          value={formData.imageUrl}
          onChange={handleChange}
          className="w-full border rounded p-2"
        />

        <input
          type="number"
          name="lowStockThreshold"
          placeholder="Low Stock Threshold"
          value={formData.lowStockThreshold}
          onChange={handleChange}
          className="w-full border rounded p-2"
        />

        <textarea
          name="description"
          placeholder="Description"
          value={formData.description}
          onChange={handleChange}
          className="w-full border rounded p-2"
        />

        <div className="flex justify-end space-x-2">
          <button
            type="button"
            onClick={() => navigate("/products")}
            className="px-4 py-2 border rounded"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isLoading}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
          >
            {isLoading ? "Creating..." : "Create Product"}
          </button>
        </div>
      </form>
    </div>
  );
};

export default NewProductPage;
