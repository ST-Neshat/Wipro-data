
import React from 'react';
import { useGetInventorySummaryQuery } from '../../services/reportsApi';
import { useGetLowStockQuery } from '../../services/productsApi';
import StatCard from '../../components/StatCard';

const DashboardPage: React.FC = () => {
  const { data: inventorySummary, isLoading, error } = useGetInventorySummaryQuery();
  const { data: lowStockProducts } = useGetLowStockQuery();

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-14 w-14 border-4 border-indigo-500 border-t-transparent"></div>
      </div>
    );
  }

 
  if (error) {
  // Check if the error has a status property
  const status = "status" in error ? error.status : null;

  return (
    <div className="bg-gradient-to-r from-red-100 to-red-200 border-l-4 border-red-600 p-5 rounded-xl shadow-md">
      <div className="flex items-center">
        <svg
          className="h-6 w-6 text-red-600 mr-2"
          viewBox="0 0 20 20"
          fill="currentColor"
        >
          <path
            fillRule="evenodd"
            d="M10 18a8 8 0 100-16 8 8 0 000 16zm-2-9a1 1 0 112 0v2a1 1 0 11-2 0V9zm2 6a1.5 1.5 0 100-3 1.5 1.5 0 000 3z"
            clipRule="evenodd"
          />
        </svg>
        <p className="text-base font-semibold text-red-800">
          {status === 403
            ? "Access denied. You do not have permission to view this dashboard."
            : "Failed to load dashboard data. Try again later."}
        </p>
      </div>
    </div>
  );
}


  return (
    <div className="space-y-10">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-4xl font-extrabold text-gray-900 tracking-tight">
          Dashboard Overview
        </h1>
        <span className="px-4 py-2 bg-indigo-100 text-indigo-700 rounded-full text-sm font-medium shadow-sm">
          Updated: {new Date().toLocaleDateString()}
        </span>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-2xl shadow-lg hover:scale-105 transform transition p-6">
          <StatCard
            title="Total Products"
            value={inventorySummary?.totalProducts?.toString() || '0'}
            color="blue"
            icon={
              <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
              </svg>
            }
          />
        </div>
        <div className="bg-gradient-to-r from-amber-400 to-amber-500 text-white rounded-2xl shadow-lg hover:scale-105 transform transition p-6">
          <StatCard
            title="Low Stock Items"
            value={inventorySummary?.lowStockItems?.toString() || '0'}
            color="amber"
            icon={
              <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            }
          />
        </div>
        <div className="bg-gradient-to-r from-rose-400 to-red-500 text-white rounded-2xl shadow-lg hover:scale-105 transform transition p-6">
          <StatCard
            title="Out of Stock"
            value={inventorySummary?.outOfStockItems?.toString() || '0'}
            color="red"
            icon={
              <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            }
          />
        </div>
        <div className="bg-gradient-to-r from-green-400 to-emerald-500 text-white rounded-2xl shadow-lg hover:scale-105 transform transition p-6">
          <StatCard
            title="Inventory Value"
            value={`$${(inventorySummary?.totalInventoryValue || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}`}
            color="green"
            icon={
              <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 01118 0z" />
              </svg>
            }
          />
        </div>
      </div>

      {/* Low Stock Alert */}
      {lowStockProducts && lowStockProducts.length > 0 && (
        <div className="bg-gradient-to-r from-yellow-100 to-amber-200 border-l-4 border-amber-500 p-6 rounded-xl shadow-md">
          <div className="flex items-center space-x-3">
            <svg className="h-6 w-6 text-amber-600" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
            <p className="text-sm font-semibold text-amber-800">
              ⚠ {lowStockProducts.length} product(s) are running low on inventory.
            </p>
          </div>
        </div>
      )}

      {/* Two-column layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        {/* Top Products */}
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100 hover:shadow-2xl transition">
          <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            🏆 Top Products by Value
          </h3>
          <ul className="divide-y divide-gray-200">
            {inventorySummary?.topProducts?.length ? (
              inventorySummary.topProducts.map((product, index) => (
                <li key={index} className="py-3 flex justify-between items-center">
                  <span className="text-gray-700 font-medium">{product.name}</span>
                  <span className="font-semibold text-indigo-600">
                    ${(product.value || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </li>
              ))
            ) : (
              <li className="py-3 text-center text-gray-500 italic">No data available</li>
            )}
          </ul>
        </div>

        {/* Recently Added */}
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100 hover:shadow-2xl transition">
          <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            🆕 Recently Added Products
          </h3>
          <ul className="divide-y divide-gray-200">
            {inventorySummary?.recentlyAddedProducts?.length ? (
              inventorySummary.recentlyAddedProducts.map((product, index) => (
                <li key={index} className="py-3 flex justify-between items-center">
                  <span className="text-gray-700 font-medium">{product.name}</span>
                  <span className="text-sm text-gray-500">
                    {product.date ? new Date(product.date).toLocaleDateString() : 'N/A'}
                  </span>
                </li>
              ))
            ) : (
              <li className="py-3 text-center text-gray-500 italic">No data available</li>
            )}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
