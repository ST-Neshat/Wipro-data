

import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useGetProductQuery, useUpdateProductMutation } from "../../services/productsApi";

const EditProductPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const productId = Number(id);
  const navigate = useNavigate();

  const { data: product, isLoading } = useGetProductQuery(productId);
  const [updateProduct, { isLoading: isUpdating }] = useUpdateProductMutation();

  const [formData, setFormData] = useState({
    name: "",
    sku: "",
    price: "",
    quantity: "",
    categoryId: "",
    supplierId: "",
    description: "",
    imageUrl: "",
    lowStockThreshold: "0",
    isActive: true,
  });

  useEffect(() => {
    if (product) {
      setFormData({
        name: product.name || "",
        sku: product.sku || "",
        price: product.price?.toString() || "",
        quantity: product.quantity?.toString() || "",
        categoryId: product.category?.id?.toString() || "",
        supplierId: product.supplier?.id?.toString() || "",
        description: product.description || "",
        imageUrl: product.imageUrl || "",
        lowStockThreshold: product.lowStockThreshold?.toString() || "0",
        isActive: product.isActive ?? true,
      });
    }
  }, [product]);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value, type } = e.target;
    const val = type === "checkbox" ? (e.target as HTMLInputElement).checked : value;
    setFormData((prev) => ({ ...prev, [name]: val }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
     await updateProduct({
  id: productId, // URL param
  name: formData.name,
  sku: formData.sku || null,
  price: parseFloat(formData.price),
  quantity: parseInt(formData.quantity, 10),
  categoryId: parseInt(formData.categoryId, 10),
  supplierId: parseInt(formData.supplierId, 10),
  description: formData.description || null,
  imageUrl: formData.imageUrl || null,
  lowStockThreshold: parseInt(formData.lowStockThreshold || "0", 10),
  isActive: formData.isActive,
  id: productId, // required by backend
}).unwrap();



      navigate("/products");
    } catch (err) {
      console.error("Failed to update product:", err);
    }
  };

  if (isLoading) return <p className="text-center p-4">Loading...</p>;

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Edit Product</h1>
      <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6 space-y-4">
        {/* Product fields */}
        <div>
          <label className="block text-sm font-medium">Product Name</label>
          <input type="text" name="name" value={formData.name} onChange={handleChange} required className="w-full border p-2 rounded" />
        </div>

        <div>
          <label className="block text-sm font-medium">SKU</label>
          <input type="text" name="sku" value={formData.sku} onChange={handleChange} required className="w-full border p-2 rounded" />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium">Price</label>
            <input type="number" name="price" value={formData.price} onChange={handleChange} required className="w-full border p-2 rounded" />
          </div>
          <div>
            <label className="block text-sm font-medium">Quantity</label>
            <input type="number" name="quantity" value={formData.quantity} onChange={handleChange} required className="w-full border p-2 rounded" />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium">Category ID</label>
          <input type="number" name="categoryId" value={formData.categoryId} onChange={handleChange} required className="w-full border p-2 rounded" />
        </div>

        <div>
          <label className="block text-sm font-medium">Supplier ID</label>
          <input type="number" name="supplierId" value={formData.supplierId} onChange={handleChange} required className="w-full border p-2 rounded" />
        </div>

        <div>
          <label className="block text-sm font-medium">Description</label>
          <textarea name="description" value={formData.description} onChange={handleChange} rows={3} className="w-full border p-2 rounded" />
        </div>

        <div>
          <label className="block text-sm font-medium">Image URL</label>
          <input type="text" name="imageUrl" value={formData.imageUrl} onChange={handleChange} className="w-full border p-2 rounded" />
        </div>

        <div>
          <label className="block text-sm font-medium">Low Stock Threshold</label>
          <input type="number" name="lowStockThreshold" value={formData.lowStockThreshold} onChange={handleChange} min="0" className="w-full border p-2 rounded" />
        </div>

        <div className="flex items-center space-x-2">
          <input type="checkbox" name="isActive" checked={formData.isActive} onChange={handleChange} className="w-4 h-4 text-blue-600 rounded" />
          <label className="text-sm">Is Active</label>
        </div>

        <div className="flex justify-end gap-3 pt-4">
          <button type="button" onClick={() => navigate("/products")} className="px-4 py-2 border rounded">Cancel</button>
          <button type="submit" disabled={isUpdating} className="px-4 py-2 bg-blue-600 text-white rounded">
            {isUpdating ? "Updating..." : "Update Product"}
          </button>
        </div>
      </form>
    </div>
  );
};

export default EditProductPage;
