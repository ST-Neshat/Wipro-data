﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SecureShoppingApp.Data.Migrations
{
    /// <inheritdoc />
    public partial class InitialSql : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
